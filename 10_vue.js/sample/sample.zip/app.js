// app.js
import header from './components/todoHeader.js'
import router from './router/router.js'

let template = `
<div>
    <my-header></my-header>
    <router-view></router-view>
</div>
`;

new Vue({
    el: '#app',
    template,
    components: {
        'my-header': header
    },
    router
})