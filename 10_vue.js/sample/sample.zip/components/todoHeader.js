// todoHeader.js
let template = `
<div id="myDIV" class="header">
  <h2 style="margin:5px">My To Do List</h2>
  <input type="text" id="myInput" placeholder="Title...">
  <span onclick="newElement()" class="addBtn">Add</span>
  <router-link v-bind:to="{'name': 'items'}">글목록</router-link>
</div>
`;

export default {
    template
}