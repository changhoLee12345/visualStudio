// selectItems.js

let template = `
<ul id="myUL">
  <li v-for="item in itemList">{{item}}</li>
</ul>
`;


export default {
    template,
    data: function () {
        return {
            itemList: ['aaa', 'bbb', 'ccc']
        }
    }
}